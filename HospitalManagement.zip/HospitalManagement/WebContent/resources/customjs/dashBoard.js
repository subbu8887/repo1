function getContextPath() {
		 
	    return window.location.pathname.substring(0, window.location.pathname.indexOf("/",2));
	 }
var workData;
var datatableSelectFlag=0;
var Assignedby;
var data;
var status;
var sdd;
var Flag=0;
$(document).ready(function(){
	statusList();
});
function statusList() {
 status=$('#col10_filter').val();
 $.ajax({
  type : 'POST',
  url : getContextPath() + "/common/getallEmployess",
  dataType : "json",
  data:{status:status},
  
  success : function(data) {
   var result = [];
   for ( var i in data) {
	   result.push([ data[i].projectName, data[i].ScreenName,data[i].AssignedBy,data[i].AssignedTo, data[i].AssignedDate,data[i].DeadLineDate,data[i].Status,data[i].CompletedDate,data[i].WorkId, data[i].WorkDescription,data[i].Sdd,data[i].VerifiedBy,data[i].VerifiedDate]);
   }
   
   $("#id-work-status-datatable").empty();
   workData=$('#id-work-status-datatable').DataTable({
    data : result,
    columns : [ {
      title : "Project Name"
    }, {
         title : "Screen Name"
    }, {
         title : "Assigned By"
    }, {
         title : "Assigned To"
        },{
          title : "Assigned Date"
     },{
          title : "DeadLine Date"
     },{
          title : "Status"
     }],
         "bDestroy" : true,
         "bFilter" : true,
       "iDisplayLength": 5,
       "bLengthChange":false,
       "responsive": false
   });
   
  },

  error : function(jqXHR, textStatus, errorThrown) {
   alert("suServer Exception in SubMerchant list" + errorThrown);
  }
 });
 
}

 
 
