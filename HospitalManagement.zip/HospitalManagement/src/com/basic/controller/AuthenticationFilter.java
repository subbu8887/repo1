package com.basic.controller;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AuthenticationFilter implements Filter {
    private ServletContext context;

    public void init(final FilterConfig fConfig) throws ServletException {
        this.context = fConfig.getServletContext();
        this.context.log("AuthenticationFilter initialized");
    }
    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        String uri = req.getRequestURI();
        this.context.log("Requested Resource::" + uri);
        HttpSession session = req.getSession(false);
        res.setHeader("Pragma", "No-cache");
        res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        res.setDateHeader("Expires", 0);
        if (uri.indexOf("/common/login") >= 0
                || (session != null && session.getAttribute("userId") != null)
                || uri.contains("resource")
                ||uri.contains("Resource")) {
            chain.doFilter(request, response);
        } else {
            this.context.log("Unauthorized access request");
            req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
        }
  
    }

    
    @Override
    public void destroy() {
    }
}