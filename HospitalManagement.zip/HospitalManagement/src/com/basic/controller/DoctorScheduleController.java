package com.basic.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.basic.service.DoctorScheduleService;
import com.basic.dto.ScheduleDto;

@Controller
@RequestMapping("/doctorScheduleController")
public class DoctorScheduleController {
	@Autowired
	DoctorScheduleService docterScheduleService;
	@RequestMapping(value = "/getDoctorIdSearch" , method = RequestMethod.POST)  
	   public @ResponseBody String getDaysOfWeak(Model model, HttpServletRequest request){  
		 HttpSession session = request.getSession();
	        String userId = (String) session.getAttribute("userId");
		   String returnStatus="";  
		   try {     
			   returnStatus=userId;
			   } catch (Exception e) {
				 System.out.println("Exception in DocterScheduleController getDoctorIdSearch() method :" + e.getMessage()); 
				   }  
		   System.out.println("cc>>>>>>>>>>>>>>>>>>>cccccccccccc"+returnStatus);
		   return returnStatus; 
		   }
	



@RequestMapping(value = "/saveDocterScheduleTest", method = RequestMethod.POST)
public @ResponseBody String saveDocterScheduleTest(HttpServletRequest request,
ScheduleDto DocterScheduledto) {
	String blStatus = "";
	try {
		  HttpSession session = request.getSession();
		  String doctorId =(String)session.getAttribute("userId");
		  
		  DocterScheduledto.setEnteredBy(doctorId);
		  DocterScheduledto.setUpdatedby(doctorId);
		 
		  System.out.println("inside the method saveDocterSchedule() in DocterScheduleController"+DocterScheduledto.getTimeFrom());
		blStatus = docterScheduleService.saveDocterScheduleTest(DocterScheduledto);
	} catch (Exception e) {
		System.out.println("Exception saveDocterSchedule() in DocterScheduleController "+ e.getMessage());
	}
	System.out.println("Status Returened In saveDocterSchedule() in DocterScheduleController::"+blStatus);
	return blStatus;
}

@RequestMapping(value = "/cretedTimeSchedule" , method = RequestMethod.POST)  
public @ResponseBody String cretedTimeSchedule(Model model, HttpServletRequest request){  
	
//	String appointmentDate=request.getParameter("appointmentDate");
	String returnStatus="";  
	   try {
		   HttpSession session = request.getSession();
			String clinicId = (String) session.getAttribute("userId");
			String selectedDay=request.getParameter("sel");
		 returnStatus=docterScheduleService.cretedTimeSchedule(clinicId,selectedDay);
		   } catch (Exception e) {
			   System.out.println("Exception in MakeAppointmentController getAllDoctorScheduleTime() method :"     + e); 
			   }     
	   return returnStatus; 
	   }

}