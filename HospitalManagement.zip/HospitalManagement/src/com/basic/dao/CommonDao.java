package com.basic.dao;

import java.util.List;

import com.basic.model.Employees;
import com.basic.model.User;
public interface CommonDao {

	public User login(String userId, String password);

	public List<Employees> getEmployeeDetails(String userName, String status);

	public boolean saveEmployee(Employees employee);
}
