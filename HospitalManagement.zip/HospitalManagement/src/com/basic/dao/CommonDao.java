package com.basic.dao;

import com.basic.model.User;
public interface CommonDao {

	public User login(String userId, String password);
}
