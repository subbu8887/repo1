package com.basic.dao;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.basic.model.User;

@Repository("commonDao")
public class CommonDaoImpl implements CommonDao{
	private static final Logger logger = Logger.getLogger(CommonDaoImpl.class.getName());
	@Autowired
	SessionFactory sessionFactory;
	private Session session;
	@Override
	public User login(String userId, String password) {
		User user = null;
        try {
            session = sessionFactory.getCurrentSession();
            Criteria cr = session.createCriteria(User.class);
            cr.add(Restrictions.eq("userId", userId));
            cr.add(Restrictions.eq("password", password));
            user = (User) cr.uniqueResult();
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
        return user;
	}
	

}
