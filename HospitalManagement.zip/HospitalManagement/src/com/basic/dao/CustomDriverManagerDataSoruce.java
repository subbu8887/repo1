package com.basic.dao;

import org.springframework.jdbc.datasource.DriverManagerDataSource;



public class CustomDriverManagerDataSoruce extends DriverManagerDataSource{
	public CustomDriverManagerDataSoruce() {
		super();
	}
	public synchronized void setPassword(String password) {
		try {
			super.setPassword("admin");
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
}
