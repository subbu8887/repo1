package com.basic.dao;

import java.util.Date;
import java.util.List;

import com.basic.model.Doctorschedule;
import com.basic.model.Employees;

public interface DocterScheduleDao {

	boolean saveDoctorScheduleDetails(Doctorschedule doctorschedule);

	List<Doctorschedule> getDoctorScheduleByIDTest(String DoctorId, String dayOfWeek);

	List<Doctorschedule> getAllDoctorScheduleTime(String clinicId, Date date);
	Employees getAllDoctorName(String doctorId);




}
