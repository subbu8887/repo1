package com.basic.dto;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.*;


@Entity
@Table(name = "employee", catalog = "hospitaldb", schema = "")
public class Employees {
	      @Id
	    @Basic(optional = false)
	    @Column(name = "employee_code")
	    private long employeeCode;

	    @Column(name = "designation")
	    private String designation;
	   
	    @Column(name = "address_present")
	    private String addressPresent;
	    @Column(name = "address_permenant")
	    private String addressPermenant;
	    @Column(name = "mobile")
	    private String mobile;
	    @Column(name = "email")
	    private String email;
	    @Column(name = "ins_no")
	    private String insNo;
	    @Column(name = "emp_status")
	    private String empStatus;
	    @Lob
	    @Column(name = "remarks")
	    private String remarks;
	    @Basic(optional = false)
	    @Column(name = "enterdby")
	    private long enterdby;
	    @Basic(optional = false)
	    @Column(name = "date_cre")
	    @Temporal(TemporalType.TIMESTAMP)
	    private Date dateCre;
	    @Column(name = "updatedby")
	    private BigInteger updatedby;
	    @Column(name = "date_upd")
	    @Temporal(TemporalType.TIMESTAMP)
	    private Date dateUpd;
	    
	    
	    
}
