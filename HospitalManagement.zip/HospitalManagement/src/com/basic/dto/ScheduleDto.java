package com.basic.dto;

public class ScheduleDto {
	private String DayofWeak;
	private String doctorId;
	private String timeFrom;
	private String timeTo;
	private String enteredBy;
	private String updatedby;
	public String getDayofWeak() {
		return DayofWeak;
	}
	public void setDayofWeak(String dayofWeak) {
		DayofWeak = dayofWeak;
	}
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public String getTimeFrom() {
		return timeFrom;
	}
	public void setTimeFrom(String timeFrom) {
		this.timeFrom = timeFrom;
	}
	public String getTimeTo() {
		return timeTo;
	}
	public void setTimeTo(String timeTo) {
		this.timeTo = timeTo;
	}
	
	public String getEnteredBy() {
		return enteredBy;
	}
	public void setEnteredBy(String enteredBy) {
		this.enteredBy = enteredBy;
	}
	public String getUpdatedby() {
		return updatedby;
	}
	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}
	
	

}
