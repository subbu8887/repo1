package com.basic.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "appointment")
@NamedQueries({
    @NamedQuery(name = "Appointment.findAll", query = "SELECT a FROM Appointment a")})
public class Appointment implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "DOC_ID")
    private String docId;
   @Column(name = "doctor_id")
    private String doctorId;
    @Column(name = "app_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date appTime;
    @Column(name = "day_of_week")
    private String dayOfWeek;
	@Column(name = "arr_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date arrTime;
    @Column(name = "out_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date outTime;
    @Column(name = "triage")
    private Boolean triage;
    @Column(name = "purpose")
    private String purpose;
    @Column(name = "appoinment_type")
    private String appoinmentType;
    @Lob
    @Column(name = "remarks")
    private String remarks;
    @Column(name = "status")
    private String status;
    @Basic(optional = false)
    @Column(name = "enterdby")
    private String enterdby;
    @Basic(optional = false)
    @Column(name = "date_cre")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCre;
    @Column(name = "updatedby")
    private BigInteger updatedby;
    @Column(name = "date_upd")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateUpd;
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public Date getAppTime() {
		return appTime;
	}
	public void setAppTime(Date appTime) {
		this.appTime = appTime;
	}
	public String getDayOfWeek() {
		return dayOfWeek;
	}
	public void setDayOfWeek(String dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	public Date getArrTime() {
		return arrTime;
	}
	public void setArrTime(Date arrTime) {
		this.arrTime = arrTime;
	}
	public Date getOutTime() {
		return outTime;
	}
	public void setOutTime(Date outTime) {
		this.outTime = outTime;
	}
	public Boolean getTriage() {
		return triage;
	}
	public void setTriage(Boolean triage) {
		this.triage = triage;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public String getAppoinmentType() {
		return appoinmentType;
	}
	public void setAppoinmentType(String appoinmentType) {
		this.appoinmentType = appoinmentType;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEnterdby() {
		return enterdby;
	}
	public void setEnterdby(String enterdby) {
		this.enterdby = enterdby;
	}
	public Date getDateCre() {
		return dateCre;
	}
	public void setDateCre(Date dateCre) {
		this.dateCre = dateCre;
	}
	public BigInteger getUpdatedby() {
		return updatedby;
	}
	public void setUpdatedby(BigInteger updatedby) {
		this.updatedby = updatedby;
	}
	public Date getDateUpd() {
		return dateUpd;
	}
	public void setDateUpd(Date dateUpd) {
		this.dateUpd = dateUpd;
	}
    
}
