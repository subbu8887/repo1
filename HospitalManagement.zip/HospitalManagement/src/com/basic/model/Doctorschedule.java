package com.basic.model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "doctorschedule")
public class Doctorschedule {
  
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "doc_Id")
    private Integer docId;
    @Column(name = "doctor_id")
    private String doctorId;
    @Column(name = "day_of_week")
    private String dayOfWeek;
    @Column(name = "schedule_no")
    private int scheduledNumber;
    @Column(name = "time_from")
    private String timeFrom;
    @Column(name = "time_to")
    private String timeTo;
    public Integer getDocId() {
		return docId;
	}
	public void setDocId(Integer docId) {
		this.docId = docId;
	}
	@Column(name = "enterdby")
    private String enterdby;
    @Basic(optional = false)
    @Column(name = "date_cre")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCre;
    @Column(name = "updatedby")
    private String updatedby;
    @Column(name = "date_upd")
    private Date dateUpd;
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public String getDayOfWeek() {
		return dayOfWeek;
	}
	public void setDayOfWeek(String dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	public int getScheduledNumber() {
		return scheduledNumber;
	}
	public void setScheduledNumber(int scheduledNumber) {
		this.scheduledNumber = scheduledNumber;
	}
	public String getTimeFrom() {
		return timeFrom;
	}
	public void setTimeFrom(String timeFrom) {
		this.timeFrom = timeFrom;
	}
	public String getTimeTo() {
		return timeTo;
	}
	public void setTimeTo(String timeTo) {
		this.timeTo = timeTo;
	}
	public String getEnterdby() {
		return enterdby;
	}
	public void setEnterdby(String enterdby) {
		this.enterdby = enterdby;
	}
	public Date getDateCre() {
		return dateCre;
	}
	public void setDateCre(Date dateCre) {
		this.dateCre = dateCre;
	}
	public String getUpdatedby() {
		return updatedby;
	}
	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}
	public Date getDateUpd() {
		return dateUpd;
	}
	public void setDateUpd(Date dateUpd) {
		this.dateUpd = dateUpd;
	}
    
}