package com.basic.model;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;


@Entity
@Table(name = "employee")
public class Employees {
	      @Id
	      @GeneratedValue(strategy = GenerationType.AUTO)
	    @Column(name = "employee_code")
	    private Integer employeeCode;
	      @Column(name = "employee_name")
		    private String employeeName;
	 
		@Column(name = "designation")
	    private String designation;
	   
	    @Column(name = "address_present")
	    private String addressPresent;
	    @Column(name = "address_permenant")
	    private String addressPermenant;
	    @Column(name = "mobile")
	    private String mobile;
	    @Column(name = "email")
	    private String email;
	    @Column(name = "emp_status")
	    private String empStatus;
	    @Column(name = "remarks")
	    private String remarks;
	    @Column(name = "enterdby")
	    private String enterdby;
	    @Column(name = "date_cre")
	    @Temporal(TemporalType.TIMESTAMP)
	    private Date dateCre;
	    @Column(name = "date_upd")
	    @Temporal(TemporalType.TIMESTAMP)
	    private Date dateUpd;
		public Integer getEmployeeCode() {
			return employeeCode;
		}
		public void setEmployeeCode(Integer employeeCode) {
			this.employeeCode = employeeCode;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public String getAddressPresent() {
			return addressPresent;
		}
		public void setAddressPresent(String addressPresent) {
			this.addressPresent = addressPresent;
		}
		public String getAddressPermenant() {
			return addressPermenant;
		}
		public void setAddressPermenant(String addressPermenant) {
			this.addressPermenant = addressPermenant;
		}
		public String getMobile() {
			return mobile;
		}
		public void setMobile(String mobile) {
			this.mobile = mobile;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		
		public String getEmpStatus() {
			return empStatus;
		}
		public void setEmpStatus(String empStatus) {
			this.empStatus = empStatus;
		}
		public String getRemarks() {
			return remarks;
		}
		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}
		public String getEnterdby() {
			return enterdby;
		}
		public void setEnterdby(String enterdby) {
			this.enterdby = enterdby;
		}
		public Date getDateCre() {
			return dateCre;
		}
		public void setDateCre(Date dateCre) {
			this.dateCre = dateCre;
		}
		public Date getDateUpd() {
			return dateUpd;
		}
		public void setDateUpd(Date dateUpd) {
			this.dateUpd = dateUpd;
		}
	    
	    
		   public String getEmployeeName() {
				return employeeName;
			}
			public void setEmployeeName(String employeeName) {
				this.employeeName = employeeName;
			}
}
