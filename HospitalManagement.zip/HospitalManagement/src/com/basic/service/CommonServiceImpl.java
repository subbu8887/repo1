package com.basic.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.basic.dto.EmployeeDTO;
import com.basic.dto.UserDto;
import com.basic.model.User;
import com.basic.dao.CommonDao;
import com.basic.model.Employees;

/*import com.its.work.entity.Group;
*/
@Service("commonService")
@Transactional
public class CommonServiceImpl implements CommonService {
	@Autowired
	CommonDao commonDao;

	@Override
	public User login(UserDto userDTO) {User user=new User();
	  try {
		  System.out.println("Inside authenticateUser() in UserServiceImpl");
		   user = commonDao.login(userDTO.getUserId(),userDTO.getPassword());
		  }  catch (Exception e) {
			  System.out.println("Exception authenticateUser() in UserServiceImpl "+ e.getMessage());
		  }  
	  System.out.println("Return from authenticateUser() in UserServiceImpl to "+user);
		  return user;
	}

	@Override
	public String getAllDetails(String userName,String status) {
		JSONArray employeeList = null;
		JSONObject jsobObj = null;
		SimpleDateFormat dtFormat=new SimpleDateFormat("yyyy-MM-dd");
		List<Employees> EmployeeList=null;
		try {
			System.out.println("inside method  getAllDetails() in LoginserviceImpl");
			employeeList = new JSONArray();
				EmployeeList =commonDao.getEmployeeDetails(userName,status);
			if (EmployeeList!=null) {
				if (EmployeeList.size() > 0) {
					for (Employees employee : EmployeeList) {
						jsobObj = new JSONObject();
						jsobObj.put("EmployeeName", employee.getEmployeeName());
						jsobObj.put("Designation",employee.getDesignation());
						jsobObj.put("MobileNumber",employee.getMobile());
						jsobObj.put("EmailId",employee.getEmail());
						jsobObj.put("Address",employee.getAddressPresent());
						
						employeeList.add(jsobObj);
					}
				}
			
		}
			}catch (Exception e) {
				System.out.println("Exception in method  getAllGroupList()"+ e.getMessage());
		}
		System.out.println("Group List Retruened In Service:"+employeeList.toString());
		return employeeList.toString();
	}

	@Override
	public String saveEmployee(EmployeeDTO employeeDTO) {
		JSONObject jsonobjStatus =new JSONObject();
		try {
			Employees employee=new Employees();
	    
	     if(!StringUtils.isEmpty(employee)){
	    	 
	    	 employee.setEmployeeCode(employeeDTO.getEmployeeCode());
	    	 employee.setEmployeeName(employeeDTO.getFirstName());
	    	 employee.setDesignation(employeeDTO.getDesignation());
	    	 employee.setAddressPermenant(employeeDTO.getAddressPermenant());
	    	 employee.setAddressPresent(employeeDTO.getAddressPresent());
	    	 employee.setEmpStatus(employeeDTO.getEmpStatus());
	    	 employee.setMobile(employeeDTO.getMobile());
	    	 employee.setEmail(employeeDTO.getEmail());
	    	 employee.setRemarks(employeeDTO.getRemarks());
	    	 employee.setEnterdby(employeeDTO.getEnterdby());
	    	 employeeDTO.setDateCre(new Date());
	    	 employee.setDateCre(employeeDTO.getDateCre());
	    	 employeeDTO.setDateUpd(null);
	    	 employee.setDateUpd(employeeDTO.getDateUpd());
		
	    	 
		boolean blStatus=commonDao.saveEmployee(employee);
		if(blStatus==true){
			jsonobjStatus.put("status", "Success");
			jsonobjStatus.put("message", " Employee saved successfully");
		}else{
			jsonobjStatus.put("status", "Failed");
			jsonobjStatus.put("message", " Employee already exsists");
		}
	
		}
		}
		catch (Exception e) {
			System.out.println(e.getMessage()+ e);
			throw e;
		}
		return jsonobjStatus.toString();
	}}