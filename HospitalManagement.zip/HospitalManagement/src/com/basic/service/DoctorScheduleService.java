package com.basic.service;

import com.basic.dto.ScheduleDto;

public interface DoctorScheduleService {

	String saveDocterScheduleTest(ScheduleDto docterScheduledto);

	String cretedTimeSchedule(String clinicId, String selectedDay);

}
