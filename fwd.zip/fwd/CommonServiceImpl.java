package com.basic.service;

import java.text.SimpleDateFormat;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.basic.dto.UserDto;
import com.basic.model.User;
import com.basic.dao.CommonDao;
import com.basic.model.Employees;

/*import com.its.work.entity.Group;
*/
@Service("commonService")
@Transactional
public class CommonServiceImpl implements CommonService {
	@Autowired
	CommonDao commonDao;

	@Override
	public User login(UserDto userDTO) {User user=new User();
	  try {
		  System.out.println("Inside authenticateUser() in UserServiceImpl");
		   user = commonDao.login(userDTO.getUserId(),userDTO.getPassword());
		  }  catch (Exception e) {
			  System.out.println("Exception authenticateUser() in UserServiceImpl "+ e.getMessage());
		  }  
	  System.out.println("Return from authenticateUser() in UserServiceImpl to "+user);
		  return user;
	}

	@Override
	public String getAllDetails(String userName, String group, String status) {
		JSONArray employeeList = null;
		JSONObject jsobObj = null;
		SimpleDateFormat dtFormat=new SimpleDateFormat("yyyy-MM-dd");
		List<Employees> EmployeeList=null;
		try {
			System.out.println("inside method  getAllDetails() in LoginserviceImpl");
			employeeList = new JSONArray();
				EmployeeList =commonDao.getProjectManagerDetails(userName,status);
			if (EmployeeList!=null) {
				if (EmployeeList.size() > 0) {
					for (Employees employee : EmployeeList) {
						jsobObj = new JSONObject();
						jsobObj.put("AssignedBy", employee.get);
						jsobObj.put("AssignedTo",employee.getAssignedTo());
						
						jsobObj.put("projectName",workAssignment.getProjectName());
						
						employeeList.add(jsobObj);
					}
				}
			
		}
			}catch (Exception e) {
				System.out.println("Exception in method  getAllGroupList()"+ e.getMessage());
		}
		System.out.println("Group List Retruened In Service:"+employeeList.toString());
		return employeeList.toString();
	}}