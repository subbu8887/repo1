package com.basic.model;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.*;


@Entity
@Table(name = "employee", catalog = "hospitaldb", schema = "")
public class Employees {
	      @Id
	    @Basic(optional = false)
	    @Column(name = "employee_code")
	    private long employeeCode;

	    @Column(name = "designation")
	    private String designation;
	   
	    @Column(name = "address_present")
	    private String addressPresent;
	    @Column(name = "address_permenant")
	    private String addressPermenant;
	    @Column(name = "mobile")
	    private String mobile;
	    @Column(name = "email")
	    private String email;
	    @Column(name = "ins_no")
	    private String insNo;
	    @Column(name = "emp_status")
	    private String empStatus;
	    @Lob
	    @Column(name = "remarks")
	    private String remarks;
	    @Basic(optional = false)
	    @Column(name = "enterdby")
	    private long enterdby;
	    @Basic(optional = false)
	    @Column(name = "date_cre")
	    @Temporal(TemporalType.TIMESTAMP)
	    private Date dateCre;
	    @Column(name = "updatedby")
	    private BigInteger updatedby;
	    @Column(name = "date_upd")
	    @Temporal(TemporalType.TIMESTAMP)
	    private Date dateUpd;
		public long getEmployeeCode() {
			return employeeCode;
		}
		public void setEmployeeCode(long employeeCode) {
			this.employeeCode = employeeCode;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public String getAddressPresent() {
			return addressPresent;
		}
		public void setAddressPresent(String addressPresent) {
			this.addressPresent = addressPresent;
		}
		public String getAddressPermenant() {
			return addressPermenant;
		}
		public void setAddressPermenant(String addressPermenant) {
			this.addressPermenant = addressPermenant;
		}
		public String getMobile() {
			return mobile;
		}
		public void setMobile(String mobile) {
			this.mobile = mobile;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getInsNo() {
			return insNo;
		}
		public void setInsNo(String insNo) {
			this.insNo = insNo;
		}
		public String getEmpStatus() {
			return empStatus;
		}
		public void setEmpStatus(String empStatus) {
			this.empStatus = empStatus;
		}
		public String getRemarks() {
			return remarks;
		}
		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}
		public long getEnterdby() {
			return enterdby;
		}
		public void setEnterdby(long enterdby) {
			this.enterdby = enterdby;
		}
		public Date getDateCre() {
			return dateCre;
		}
		public void setDateCre(Date dateCre) {
			this.dateCre = dateCre;
		}
		public BigInteger getUpdatedby() {
			return updatedby;
		}
		public void setUpdatedby(BigInteger updatedby) {
			this.updatedby = updatedby;
		}
		public Date getDateUpd() {
			return dateUpd;
		}
		public void setDateUpd(Date dateUpd) {
			this.dateUpd = dateUpd;
		}
	    
	    
	    
}
